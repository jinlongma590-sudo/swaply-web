// src/components/OpenInAppButton.tsx
// ✅ 符合架构：使用正确的 Deep Link 格式
'use client';

import { useEffect, useState } from 'react';

interface OpenInAppButtonProps {
  listingId: string;
  variant?: 'primary' | 'secondary';
  className?: string;
}

export function OpenInAppButton({
  listingId,
  variant = 'secondary',
  className = ''
}: OpenInAppButtonProps) {
  const [isClient, setIsClient] = useState(false);
  const [attempting, setAttempting] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const tryOpenApp = () => {
    if (!isClient || attempting) return;

    setAttempting(true);

    // ✅ 符合架构：使用正确的 Deep Link scheme
    // 与 DeepLinkService 保持一致：cc.swaply.app://listing?id=xxx
    const deepLinkUrl = `cc.swaply.app://listing?id=${listingId}`;

    console.log('[OpenInApp] Attempting to open:', deepLinkUrl);

    const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
    const isAndroid = /Android/i.test(navigator.userAgent);
    const isMobile = isIOS || isAndroid;

    if (!isMobile) {
      // 桌面端：跳转到下载页
      console.log('[OpenInApp] Desktop detected, redirecting to download page');
      window.location.href = '/download';
      setAttempting(false);
      return;
    }

    // ✅ 移动端：尝试打开 App
    try {
      // 策略 1: 直接跳转 Deep Link
      window.location.href = deepLinkUrl;

      // 策略 2: 如果 2 秒后页面没隐藏，说明 App 未安装
      const fallbackTimer = setTimeout(() => {
        if (!document.hidden) {
          console.log('[OpenInApp] App not installed, redirecting to download page');
          window.location.href = '/download';
        } else {
          console.log('[OpenInApp] App opened successfully');
        }
        setAttempting(false);
      }, 2000);

      // 策略 3: 监听页面隐藏（表示 App 打开了）
      const handleVisibilityChange = () => {
        if (document.hidden) {
          console.log('[OpenInApp] Page hidden, app is opening');
          clearTimeout(fallbackTimer);
          setAttempting(false);
        }
      };

      document.addEventListener('visibilitychange', handleVisibilityChange, { once: true });

      // 清理：3秒后移除监听器
      setTimeout(() => {
        document.removeEventListener('visibilitychange', handleVisibilityChange);
      }, 3000);

    } catch (err) {
      console.error('[OpenInApp] Error:', err);
      setAttempting(false);
    }
  };

  const baseClasses = variant === 'primary'
    ? "inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-blue-600 to-indigo-700 px-5 py-3 font-semibold text-white shadow-[0_10px_24px_rgba(37,99,235,0.45)] hover:opacity-95 active:scale-[0.99] transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
    : "inline-flex items-center gap-2 rounded-xl border border-blue-200 bg-white/80 px-4 py-2 font-semibold text-blue-700 shadow-sm hover:bg-white active:scale-[0.99] transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed";

  if (!isClient) {
    return (
      <div className={`${baseClasses} ${className}`}>
        {variant === 'primary' ? 'Get Swaply App' : 'Open in App'}
      </div>
    );
  }

  return (
    <button
      onClick={tryOpenApp}
      disabled={attempting}
      className={`${baseClasses} ${className}`}
      type="button"
    >
      {attempting ? (
        <>
          <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Opening...
        </>
      ) : (
        variant === 'primary' ? 'Get Swaply App' : 'Open in App'
      )}
    </button>
  );
}