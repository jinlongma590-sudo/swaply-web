// src/app/reset-password/page.tsx
// ✅ 修复版本：使用正确的 URL fragment 格式传递 token
// ✅ 符合 Supabase 的 recovery token 规范

'use client';

import { useEffect, useState } from 'react';

// ✅ 使用与 iOS/Android 配置一致的 scheme
const APP_SCHEME = 'cc.swaply.app://reset-password';

// 用于解析 URL hash（#access_token=...&refresh_token=...&type=recovery）
function parseHashParams(hash: string): URLSearchParams {
  const clean = hash.startsWith('#') ? hash.slice(1) : hash;
  return new URLSearchParams(clean);
}

export default function ResetPasswordBridgePage() {
  const [message, setMessage] = useState<string>('Verifying your reset link...');
  const [appUrl, setAppUrl] = useState<string>('');
  const [debugInfo, setDebugInfo] = useState<string>('');
  const [showManualButton, setShowManualButton] = useState(false);
  const [buttonText, setButtonText] = useState('Open Swaply App');
  const [isError, setIsError] = useState(false);

  useEffect(() => {
    const url = new URL(window.location.href);
    const qs = url.searchParams;
    const hs = parseHashParams(window.location.hash);

    // 🔍 调试信息
    const debug = [
      `🔍 Debug Info:`,
      `Full URL: ${window.location.href}`,
      `Query params: ${JSON.stringify(Object.fromEntries(qs.entries()))}`,
      `Hash params: ${JSON.stringify(Object.fromEntries(hs.entries()))}`,
    ].join('\n');

    console.log(debug);
    if (process.env.NODE_ENV === 'development') {
      setDebugInfo(debug);
    }

    // ============================================================
    // ✅ 关键修复1：更全面的token提取逻辑
    // Supabase可能发送的格式：
    // 1. #access_token=xxx&refresh_token=yyy&type=recovery (最常见)
    // 2. ?token=xxx (旧格式)
    // 3. ?token_hash=xxx (某些版本)
    // ============================================================

    // 从query和hash中提取所有可能的token
    const tokens = {
      // Hash参数（优先级最高，Supabase 新版本使用这个）
      hash_access_token: hs.get('access_token') ?? undefined,
      hash_refresh_token: hs.get('refresh_token') ?? undefined,
      hash_token: hs.get('token') ?? undefined,

      // Query参数
      token: qs.get('token') ?? undefined,
      token_hash: qs.get('token_hash') ?? undefined,
      access_token: qs.get('access_token') ?? undefined,

      // 其他参数
      refresh_token: hs.get('refresh_token') ?? qs.get('refresh_token') ?? undefined,
      type: hs.get('type') ?? qs.get('type') ?? 'recovery',
    };

    // 选择第一个非空token（优先hash参数）
    const finalToken = tokens.hash_access_token ||
                       tokens.token ||
                       tokens.access_token ||
                       tokens.hash_token ||
                       tokens.token_hash;

    const finalRefreshToken = tokens.hash_refresh_token || tokens.refresh_token;

    console.log('🔑 Token extraction:', {
      found: finalToken ? 'YES' : 'NO',
      source: tokens.hash_access_token ? 'hash_access_token' :
              tokens.token ? 'query_token' :
              tokens.access_token ? 'query_access_token' :
              tokens.hash_token ? 'hash_token' :
              tokens.token_hash ? 'query_token_hash' : 'NONE',
      has_refresh_token: finalRefreshToken ? 'YES' : 'NO',
      type: tokens.type,
    });

    // ============================================================
    // ✅ 检测错误情况
    // ============================================================
    const error = qs.get('error') ?? hs.get('error');
    const errorCode = qs.get('error_code') ?? hs.get('error_code');
    const errorDesc = qs.get('error_description') ?? hs.get('error_description');

    if (error || errorCode) {
      console.error('❌ Error detected:', { error, errorCode, errorDesc });
      setIsError(true);

      setMessage(
        errorDesc ||
        error ||
        'This reset link has expired or is invalid. Please request a new one from the app.'
      );

      // ✅ 关键修复2：错误也要用 fragment 格式
      const errorFragment = new URLSearchParams();
      errorFragment.set('error', error || errorCode || 'unknown');
      if (errorDesc) errorFragment.set('error_description', errorDesc);

      const errorAppUrl = `${APP_SCHEME}#${errorFragment.toString()}`;
      setAppUrl(errorAppUrl);
      setShowManualButton(true);
      setButtonText('Return to App');

      setTimeout(() => {
        console.log('🚀 Auto-opening app with error URL...');
        tryOpenApp(errorAppUrl);
      }, 1500);

      return;
    }

    // ============================================================
    // ✅ 处理无token情况
    // ============================================================
    if (!finalToken) {
      console.warn('⚠️ No token found in URL');
      setIsError(true);
      setMessage('No reset token found. Please click "Forgot Password" in the app to get a new reset link.');

      const noTokenFragment = new URLSearchParams({
        error: 'no_token',
        error_description: 'Token not found in reset link',
      });

      const noTokenUrl = `${APP_SCHEME}#${noTokenFragment.toString()}`;
      setAppUrl(noTokenUrl);
      setShowManualButton(true);
      setButtonText('Return to App');

      setTimeout(() => {
        tryOpenApp(noTokenUrl);
      }, 1500);

      return;
    }

    // ============================================================
    // ✅ 关键修复3：使用 fragment（#）而不是 query（?）
    // 这是 Supabase 的标准格式！
    // ============================================================
    const fragment = new URLSearchParams();

    // 必须参数（使用 Supabase 的标准字段名）
    fragment.set('access_token', finalToken);  // ← 关键：用 access_token，不是 token
    fragment.set('type', tokens.type);

    // 可选参数
    if (finalRefreshToken) {
      fragment.set('refresh_token', finalRefreshToken);
    }

    // ✅ 构造正确的 deep link：scheme://host#fragment
    const finalAppUrl = `${APP_SCHEME}#${fragment.toString()}`;
    setAppUrl(finalAppUrl);

    console.log('🚀 Final app URL constructed (correct format):');
    console.log('   Format: scheme://host#access_token=...&type=recovery');
    console.log('   URL:', finalAppUrl.replace(/access_token=[^&]+/g, 'access_token=***'));

    // ============================================================
    // ✅ 改进的自动打开策略
    // ============================================================
    setMessage('Opening Swaply app...');
    setShowManualButton(true);
    setButtonText('Opening...');

    // 立即尝试打开
    setTimeout(() => {
      tryOpenApp(finalAppUrl);

      // 1秒后更新按钮文本
      setTimeout(() => {
        setButtonText('Tap here if app did not open');
        setMessage('If the app did not open automatically, tap the button below.');
      }, 1000);
    }, 300);

  }, []);

  // ============================================================
  // ✅ 多策略deep link打开
  // ============================================================
  const tryOpenApp = (url: string) => {
    console.log('📱 Attempting to open app:', url.replace(/access_token=[^&]+/g, 'access_token=***'));

    try {
      // 策略1: 使用 window.location.href（最兼容）
      window.location.href = url;

      // 策略2: iframe方法
      setTimeout(() => {
        if (document.hasFocus()) {
          console.log('🔄 Trying iframe method...');
          const iframe = document.createElement('iframe');
          iframe.style.display = 'none';
          iframe.src = url;
          document.body.appendChild(iframe);
          setTimeout(() => document.body.removeChild(iframe), 1000);
        }
      }, 1500);

      // 策略3: anchor点击
      setTimeout(() => {
        if (document.hasFocus()) {
          console.log('🔄 Trying anchor click method...');
          const link = document.createElement('a');
          link.href = url;
          link.style.display = 'none';
          document.body.appendChild(link);
          link.click();
          setTimeout(() => document.body.removeChild(link), 1000);
        }
      }, 2500);

    } catch (err) {
      console.error('❌ Failed to open app:', err);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '24px',
      background: isError
        ? 'linear-gradient(135deg, #fff5f5 0%, #ffe5e5 100%)'
        : 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    }}>
      <div style={{
        maxWidth: '420px',
        width: '100%',
        backgroundColor: 'white',
        borderRadius: '16px',
        padding: '40px 32px',
        boxShadow: isError
          ? '0 10px 40px rgba(239, 68, 68, 0.15)'
          : '0 10px 40px rgba(59, 130, 246, 0.15)',
        border: isError
          ? '2px solid rgba(239, 68, 68, 0.1)'
          : '2px solid rgba(59, 130, 246, 0.1)',
      }}>
        {/* Logo/Icon */}
        <div style={{
          width: '80px',
          height: '80px',
          margin: '0 auto 24px',
          background: isError
            ? 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)'
            : 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '40px',
          boxShadow: isError
            ? '0 8px 20px rgba(239, 68, 68, 0.3)'
            : '0 8px 20px rgba(59, 130, 246, 0.3)',
        }}>
          <span style={{ color: 'white' }}>
            {isError ? '⚠️' : '🔐'}
          </span>
        </div>

        {/* Title */}
        <h1 style={{
          margin: '0 0 16px',
          fontSize: '28px',
          fontWeight: '700',
          textAlign: 'center',
          background: isError
            ? 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)'
            : 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
        }}>
          {isError ? 'Reset Link Issue' : 'Swaply'}
        </h1>

        {/* Message */}
        <p style={{
          margin: '0 0 32px',
          fontSize: '16px',
          lineHeight: '1.6',
          textAlign: 'center',
          color: '#6b7280',
        }}>
          {message}
        </p>

        {/* Manual Open Button */}
        {showManualButton && appUrl && (
          <a
            href={appUrl}
            onClick={(e) => {
              e.preventDefault();
              tryOpenApp(appUrl);
            }}
            style={{
              display: 'block',
              width: '100%',
              padding: '16px 24px',
              background: isError
                ? 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)'
                : 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '12px',
              fontSize: '16px',
              fontWeight: '600',
              textAlign: 'center',
              transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
              cursor: 'pointer',
              boxShadow: isError
                ? '0 4px 12px rgba(239, 68, 68, 0.3)'
                : '0 4px 12px rgba(59, 130, 246, 0.3)',
              border: 'none',
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
              e.currentTarget.style.boxShadow = isError
                ? '0 6px 16px rgba(239, 68, 68, 0.4)'
                : '0 6px 16px rgba(59, 130, 246, 0.4)';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = isError
                ? '0 4px 12px rgba(239, 68, 68, 0.3)'
                : '0 4px 12px rgba(59, 130, 246, 0.3)';
            }}
          >
            {buttonText}
          </a>
        )}

        {/* Instructions */}
        <div style={{
          marginTop: '32px',
          paddingTop: '24px',
          borderTop: '1px solid #e5e7eb',
          fontSize: '13px',
          color: '#9ca3af',
          textAlign: 'center',
          lineHeight: '1.5',
        }}>
          {isError ? (
            <>
              <strong style={{ color: '#6b7280', display: 'block', marginBottom: '8px' }}>
                To request a new reset link:
              </strong>
              1. Open the Swaply app<br/>
              2. Go to Login screen<br/>
              3. Tap &ldquo;Forgot Password&rdquo;<br/>
              4. Enter your email<br/>
              5. Open the new link on this device
            </>
          ) : (
            <>
              This page verifies your password reset link<br/>
              and opens it in the Swaply app.
            </>
          )}
        </div>

        {/* Debug info (development only) */}
        {debugInfo && process.env.NODE_ENV === 'development' && (
          <details style={{
            marginTop: '16px',
            padding: '12px',
            backgroundColor: '#f9fafb',
            borderRadius: '8px',
            fontSize: '11px',
            fontFamily: 'monospace',
            cursor: 'pointer',
          }}>
            <summary style={{ fontWeight: '600', marginBottom: '8px', color: '#6b7280' }}>
              🔧 Debug Info (Dev Only)
            </summary>
            <pre style={{
              margin: 0,
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-all',
              color: '#4b5563',
              maxHeight: '200px',
              overflow: 'auto',
            }}>
              {debugInfo}
              {'\n\nConstructed App URL:\n'}
              {appUrl.replace(/access_token=[^&]+/g, 'access_token=***')}
            </pre>
          </details>
        )}
      </div>
    </div>
  );
}